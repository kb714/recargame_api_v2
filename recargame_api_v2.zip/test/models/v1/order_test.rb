require 'test_helper'

class V1::OrderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
